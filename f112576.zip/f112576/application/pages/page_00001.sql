prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>13295460441845663907
,p_default_application_id=>112576
,p_default_id_offset=>0
,p_default_owner=>'WKSP_CKEENAN2'
);
wwv_flow_api.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_api.id(17843674423292242897)
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'O''Hare International Airport Project '
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ISAAC-MCSORLEY@UIOWA.EDU'
,p_last_upd_yyyymmddhh24miss=>'20211208023059'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17843684297355242910)
,p_plug_name=>'Chicago O''Hare International Airport Project'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon:t-HeroRegion--headingFontAlt:js-headingLevel-3'
,p_plug_template=>wwv_flow_api.id(17843555093581242850)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17847232382875334302)
,p_plug_name=>'Project Overview'
,p_region_template_options=>'#DEFAULT#:t-Region--accent8:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(17843577177964242858)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Almost 88% of citizens in the U.S. have taken a commercial flight in their lifetime, and while cancellations, layovers, and delays make flying most difficult for consumers, our goal is too to assist fliers who are worried about their flight getting c'
||'anceled.',
'We will use the data we gathered to answer questions to help fliers make a more informed decision about what day, month, and airline they should choose to fly out of. ',
'</br>',
'</br>',
'This project uses data from the <a href="https://www.kaggle.com/gauravmehta13/airline-flight-delays?select=flights.csv"> 2015 Kaggle data gathered on Commercial Air Flight Delays</a>.',
'Each record represents a single flight, including the airline name, flight number, destination airport, and flight distance, as well as scheduled/actual departure and arrival times.',
'Data from this Kaggle set comes from over 5 million commercial flights disclosing the data to the U.S. DOT Air Travel Consumer Report. We had to significantly cut down the data in order to be able to manipulate it and transform it into usable data fo'
||unistr('r analysis. We have limited our data to only looking at the Chicago O\2019Hare airport. Frequent fliers of O\2019Hare can benefit from our analysis.'),
'<br/><br/>',
' <br/>',
'<br/> <i> The pages of our web application will display the data tables and analyses in the form of reports and charts that help flyers make better decisions when flying out of Chicago O'' Hare Airport. </i>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17862999599153863205)
,p_plug_name=>'OharePic'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--hiddenOverflow'
,p_region_attributes=>'style="width:100%" '
,p_plug_template=>wwv_flow_api.id(17843577177964242858)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'<img src="#APP_IMAGES#OHareDBM.jpg">'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17903078283542511206)
,p_plug_name=>'Questions we will answer'
,p_region_template_options=>'#DEFAULT#:t-Region--accent15:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(17843577177964242858)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<ul style=\201Clist-style-type:square\201D> <li>'),
'<b>  Are certain days of the week better/worse to fly on? ',
'</li> <b> <br/> ',
'<li> <b> Which airlines have the highest percentage chance of a flight getting canceled?',
'<b> </li>',
unistr('<b> </li> <br/> <li> What airlines had the most flights out of O\2019Hare?'),
'<b> </li> <br/>  <li> What is the percentage chance that your flight will get canceled/delayed? </li> <br/> ',
'<li><b>What is the average delay time for each airline? </li> <b> ',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.component_end;
end;
/
