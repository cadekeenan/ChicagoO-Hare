prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>13295460441845663907
,p_default_application_id=>112576
,p_default_id_offset=>0
,p_default_owner=>'WKSP_CKEENAN2'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(17843674423292242897)
,p_name=>'Q1'
,p_alias=>'Q1'
,p_step_title=>'Q1'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ISAAC-MCSORLEY@UIOWA.EDU'
,p_last_upd_yyyymmddhh24miss=>'20211208031056'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13995463277597546006)
,p_plug_name=>unistr('Q1: In 2015 Chicago O\2019Hare airport, are certain days of the week better/worse to fly on? What days had the highest percentage of cancelations?')
,p_region_template_options=>'#DEFAULT#:t-Region--accent8:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(17843577177964242858)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<b>Answer</b> </br>',
unistr('The results of this query (shown below) indicate that the worst day to fly on if you are trying to avoid a canceled flight in Chicago O\2019Hare in 2015 was Sunday, followed by Monday. The day with the smallest chance of getting canceled was Friday.  ')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17903081843746511242)
,p_plug_name=>'Day vs Cancelation %'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(17843577177964242858)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(17903081993643511243)
,p_region_id=>wwv_flow_api.id(17903081843746511242)
,p_chart_type=>'bar'
,p_title=>'Day vs Cancelation %'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'on'
,p_data_cursor_behavior=>'smooth'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'value-desc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(17903082006707511244)
,p_chart_id=>wwv_flow_api.id(17903081993643511243)
,p_seq=>10
,p_name=>'New'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT Day, ROUND(COUNT(FLIGHTS.FLIGHT_ID)/Number_of_Flights,3)*100 AS PercentageCancelled    ',
'',
'FROM FLIGHTS JOIN (SELECT Day_of_week, ',
'',
'CASE  ',
'',
'WHEN DAY_OF_WEEK = ''1'' THEN ''Monday'' ',
'',
'WHEN DAY_OF_WEEK = ''2'' THEN ''Tuesday'' ',
'',
'WHEN DAY_OF_WEEK = ''3'' THEN ''Wednesday'' ',
'',
'WHEN DAY_OF_WEEK = ''4'' THEN ''Thursday'' ',
'',
'WHEN DAY_OF_WEEK = ''5'' THEN ''Friday'' ',
'',
'WHEN DAY_OF_WEEK = ''6'' THEN ''Saturday'' ',
'',
'WHEN DAY_OF_WEEK = ''7'' THEN ''Sunday'' ',
'',
'END AS Day, ',
'',
'COUNT(FLIGHT_ID) AS Number_of_Flights    ',
'',
'FROM FLIGHTS GROUP BY DAY_OF_WEEK, CASE  ',
'',
'WHEN DAY_OF_WEEK = ''1'' THEN ''Monday'' ',
'',
'WHEN DAY_OF_WEEK = ''2'' THEN ''Tuesday'' ',
'',
'WHEN DAY_OF_WEEK = ''3'' THEN ''Wednesday'' ',
'',
'WHEN DAY_OF_WEEK = ''4'' THEN ''Thursday'' ',
'',
'WHEN DAY_OF_WEEK = ''5'' THEN ''Friday'' ',
'',
'WHEN DAY_OF_WEEK = ''6'' THEN ''Saturday'' ',
'',
'WHEN DAY_OF_WEEK = ''7'' THEN ''Sunday'' END) T ON T.Day_of_week = FLIGHTS.day_of_week    ',
'',
'WHERE CANCELLED = ''1''    ',
'',
'GROUP BY Day, Number_of_flights     ',
'',
'ORDER BY COUNT(FLIGHTS.FLIGHT_ID)/Number_of_Flights DESC  ',
'',
' '))
,p_series_name_column_name=>'DAY'
,p_items_value_column_name=>'PERCENTAGECANCELLED'
,p_items_label_column_name=>'DAY'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(17903082379716511247)
,p_chart_id=>wwv_flow_api.id(17903081993643511243)
,p_axis=>'y2'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_split_dual_y=>'auto'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(17903082151430511245)
,p_chart_id=>wwv_flow_api.id(17903081993643511243)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'Day'
,p_title_font_family=>'Courier New'
,p_title_font_size=>'18'
,p_title_font_color=>'#000000'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(17903082255228511246)
,p_chart_id=>wwv_flow_api.id(17903081993643511243)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Percentage Canceled'
,p_title_font_family=>'Courier New'
,p_title_font_size=>'18'
,p_title_font_color=>'#000000'
,p_format_type=>'decimal'
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(18814105755928979207)
,p_name=>'Title'
,p_template=>wwv_flow_api.id(17843577177964242858)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--accent8:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT Day, ROUND(COUNT(FLIGHTS.FLIGHT_ID)/Number_of_Flights,3)*100 || ''%'' AS PercentageCancelled    ',
'',
'FROM FLIGHTS JOIN (SELECT Day_of_week, ',
'',
'CASE  ',
'',
'WHEN DAY_OF_WEEK = ''1'' THEN ''Monday'' ',
'',
'WHEN DAY_OF_WEEK = ''2'' THEN ''Tuesday'' ',
'',
'WHEN DAY_OF_WEEK = ''3'' THEN ''Wednesday'' ',
'',
'WHEN DAY_OF_WEEK = ''4'' THEN ''Thursday'' ',
'',
'WHEN DAY_OF_WEEK = ''5'' THEN ''Friday'' ',
'',
'WHEN DAY_OF_WEEK = ''6'' THEN ''Saturday'' ',
'',
'WHEN DAY_OF_WEEK = ''7'' THEN ''Sunday'' ',
'',
'END AS Day, ',
'',
'COUNT(FLIGHT_ID) AS Number_of_Flights    ',
'',
'FROM FLIGHTS GROUP BY DAY_OF_WEEK, CASE  ',
'',
'WHEN DAY_OF_WEEK = ''1'' THEN ''Monday'' ',
'',
'WHEN DAY_OF_WEEK = ''2'' THEN ''Tuesday'' ',
'',
'WHEN DAY_OF_WEEK = ''3'' THEN ''Wednesday'' ',
'',
'WHEN DAY_OF_WEEK = ''4'' THEN ''Thursday'' ',
'',
'WHEN DAY_OF_WEEK = ''5'' THEN ''Friday'' ',
'',
'WHEN DAY_OF_WEEK = ''6'' THEN ''Saturday'' ',
'',
'WHEN DAY_OF_WEEK = ''7'' THEN ''Sunday'' END) T ON T.Day_of_week = FLIGHTS.day_of_week    ',
'',
'WHERE CANCELLED = ''1''    ',
'',
'GROUP BY Day, Number_of_flights     ',
'',
'ORDER BY COUNT(FLIGHTS.FLIGHT_ID)/Number_of_Flights DESC  ',
'',
' '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(17843614794487242872)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(18814106183378979208)
,p_query_column_id=>1
,p_column_alias=>'DAY'
,p_column_display_sequence=>10
,p_column_heading=>'Day'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(18814106583019979209)
,p_query_column_id=>2
,p_column_alias=>'PERCENTAGECANCELLED'
,p_column_display_sequence=>20
,p_column_heading=>'Percentage Cancelled'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.component_end;
end;
/
