prompt --application/pages/page_00013
begin
--   Manifest
--     PAGE: 00013
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>13295460441845663907
,p_default_application_id=>112576
,p_default_id_offset=>0
,p_default_owner=>'WKSP_CKEENAN2'
);
wwv_flow_api.create_page(
 p_id=>13
,p_user_interface_id=>wwv_flow_api.id(17843674423292242897)
,p_name=>'Q4'
,p_alias=>'Q4'
,p_step_title=>unistr('Q4: Q4: What airlines had the most flights out of O\2019Hare? Return the top 5 airlines with the most flights.')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ISAAC-MCSORLEY@UIOWA.EDU'
,p_last_upd_yyyymmddhh24miss=>'20211207002506'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13995463400124546008)
,p_plug_name=>'Percentage of Flights By Airline'
,p_region_template_options=>'#DEFAULT#:t-Region--accent15:t-Region--stacked:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(17843577177964242858)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>'SELECT AIRLINE, ROUND(COUNT(FLIGHT_ID)/(SELECT COUNT(FLIGHT_ID) AS total FROM FLIGHTS),3) AS percentage_of_total FROM FLIGHTS JOIN AIRLINE ON AIRLINE.AIRLINEID= FLIGHTS.AIRLINEID GROUP BY AIRLINE '
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(13995463515391546009)
,p_region_id=>wwv_flow_api.id(13995463400124546008)
,p_chart_type=>'pie'
,p_title=>'Percentage of Total Flights out of Chicago O''Hare in 2015'
,p_height=>'283'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'on'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_value_format_type=>'percent'
,p_value_decimal_places=>1
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(13995463641186546010)
,p_chart_id=>wwv_flow_api.id(13995463515391546009)
,p_seq=>10
,p_name=>'Chart'
,p_data_source_type=>'SQL'
,p_data_source=>'SELECT AIRLINE, ROUND(COUNT(FLIGHT_ID)/(SELECT COUNT(FLIGHT_ID) AS total FROM FLIGHTS),3) AS percentage_of_total FROM FLIGHTS JOIN AIRLINE ON AIRLINE.AIRLINEID= FLIGHTS.AIRLINEID GROUP BY AIRLINE '
,p_items_value_column_name=>'PERCENTAGE_OF_TOTAL'
,p_items_label_column_name=>'AIRLINE'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13995464084541546014)
,p_plug_name=>'Q4: What airlines had the most flights out of Chicago O''Hare in 2015?'
,p_region_template_options=>'#DEFAULT#:t-Region--accent8:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(17843577177964242858)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13995464133680546015)
,p_plug_name=>'Answer'
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(17843577177964242858)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_source=>'As you can see below, American Airlines had the most flights out of all the airlines in Chicago O'' Hare in 2015 with over 12,000 flights. Below (left) we have shown the top airlines in terms of counts of flights, and on the right we show an interacti'
||'ve pie chart that represents the percentage that each airline takes up out of all of the flights out of O''Hare.'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(18203868366991896063)
,p_name=>'Top 5 Airlines With The Most Fights'
,p_template=>wwv_flow_api.id(17843577177964242858)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--accent15:t-Region--stacked:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT AIRLINE.AIRLINE, COUNT(FLIGHTS.FLIGHT_ID) AS TotalFlights FROM FLIGHTS',
'JOIN AIRLINE ON AIRLINE.AIRLINEID = FLIGHTS.AIRLINEID',
'GROUP BY AIRLINE.AIRLINE',
'ORDER BY COUNT(FLIGHTS.FLIGHT_ID) DESC',
'FETCH FIRST 5 ROWS ONLY',
'',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(17843614794487242872)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(18203868736547896064)
,p_query_column_id=>1
,p_column_alias=>'AIRLINE'
,p_column_display_sequence=>10
,p_column_heading=>'Airline'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(18203869182234896066)
,p_query_column_id=>2
,p_column_alias=>'TOTALFLIGHTS'
,p_column_display_sequence=>20
,p_column_heading=>'Total Flights'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17903079652319511220)
,p_name=>'P13_NEW'
,p_item_sequence=>60
,p_source=>'#APP_FILES#American-Eagle-Heritage-Livery-1.jpeg'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_tag_attributes=>'style="width:100%"'
,p_field_template=>wwv_flow_api.id(17843647229019242885)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'URL'
,p_attribute_02=>'American Eagle Airplane'
);
wwv_flow_api.component_end;
end;
/
