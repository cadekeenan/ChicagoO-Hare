prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>13295460441845663907
,p_default_application_id=>112576
,p_default_id_offset=>0
,p_default_owner=>'WKSP_CKEENAN2'
);
wwv_flow_api.create_page(
 p_id=>7
,p_user_interface_id=>wwv_flow_api.id(17843674423292242897)
,p_name=>'Delayed'
,p_alias=>'DELAYED'
,p_step_title=>'Delayed'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'CKEENAN1@UIOWA.EDU'
,p_last_upd_yyyymmddhh24miss=>'20211202173045'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(18255175023219422055)
,p_plug_name=>'Delayed'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(17843572897620242856)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'DELAYED'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Delayed'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(18255175127221422055)
,p_name=>'Delayed'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'CKEENAN1@UIOWA.EDU'
,p_internal_uid=>18255175127221422055
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18255175580775422057)
,p_db_column_name=>'FLIGHT_ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Flight ID'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18255175960902422057)
,p_db_column_name=>'AIR_SYSTEM_DELAY'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Air System Delay'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18255176373156422058)
,p_db_column_name=>'SECURITY_DELAY'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Security Delay'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18255176753956422058)
,p_db_column_name=>'AIRLINE_DELAY'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Airline Delay'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18255177181781422058)
,p_db_column_name=>'LATE_AIRCRAFT_DELAY'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Late Aircraft Delay'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18255177567512422058)
,p_db_column_name=>'WEATHER_DELAY'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Weather Delay'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18255177992147422058)
,p_db_column_name=>'TOTALDELAY'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Total Delay'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(18255179956832423031)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'182551800'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FLIGHT_ID:AIR_SYSTEM_DELAY:SECURITY_DELAY:AIRLINE_DELAY:LATE_AIRCRAFT_DELAY:WEATHER_DELAY:TOTALDELAY'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(18537631723956994305)
,p_plug_name=>'<b> Delayed <b>'
,p_region_template_options=>'#DEFAULT#:t-Region--accent8:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(17843577177964242858)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(17842686087517242818)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(17843651399565242887)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_header=>'Airline delays may vary from different delay types, such as air system delays. security delays, airline delays, late aircraft delay, weather delay, and total delay time (minutes).'
);
wwv_flow_api.component_end;
end;
/
