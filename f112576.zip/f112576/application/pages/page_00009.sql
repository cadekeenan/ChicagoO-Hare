prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>13295460441845663907
,p_default_application_id=>112576
,p_default_id_offset=>0
,p_default_owner=>'WKSP_CKEENAN2'
);
wwv_flow_api.create_page(
 p_id=>9
,p_user_interface_id=>wwv_flow_api.id(17843674423292242897)
,p_name=>'Q5'
,p_alias=>'Q5'
,p_step_title=>'Q5'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ISAAC-MCSORLEY@UIOWA.EDU'
,p_last_upd_yyyymmddhh24miss=>'20211207191002'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(19668739412299986228)
,p_name=>'Q5: When flying out of Chicago O''Hare, what is the chance that any flight will get canceled or delayed?'
,p_template=>wwv_flow_api.id(17843577177964242858)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--accent8:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT (SELECT ROUND((SELECT COUNT(flight_id) * 100   ',
'',
'FROM Flights   ',
'',
'WHERE Cancelled = ''1'')  ',
'',
'/   ',
'',
'(SELECT COUNT(Flight_ID)   ',
'',
'FROM Flights),3) || ''%''  ',
'',
'FROM Flights    ',
'',
'FETCH FIRST ROW ONLY ',
'',
') AS PercentageCancelled, ',
'',
'(SELECT ROUND((SELECT COUNT(Delayed.Flight_ID) * 100  ',
'',
'FROM Flights JOIN Delayed ON Flights.Flight_ID = Delayed.Flight_ID)  ',
'',
'/  ',
'',
'(SELECT COUNT(Flight_ID)   ',
'',
'FROM Flights),2) || ''%''  ',
'',
'FROM Flights    ',
'',
'FETCH FIRST ROW ONLY  ) AS PercentageDelayed ',
'',
'FROM FLIGHTS ',
'',
'FETCH FIRST ROW ONLY '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(17843614794487242872)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(19668739858017986229)
,p_query_column_id=>1
,p_column_alias=>'PERCENTAGECANCELLED'
,p_column_display_sequence=>10
,p_column_heading=>'Percentage Cancelled'
,p_use_as_row_header=>'N'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(19668740241834986230)
,p_query_column_id=>2
,p_column_alias=>'PERCENTAGEDELAYED'
,p_column_display_sequence=>20
,p_column_heading=>'Percentage Delayed'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17903079926247511223)
,p_plug_name=>'Answer'
,p_parent_plug_id=>wwv_flow_api.id(19668739412299986228)
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(17843577177964242858)
,p_plug_display_sequence=>10
,p_plug_source=>'The query results below show that on any given flight out of Chicago O''Hare in 2015, 32% of flights go delayed, and 6% of flights got canceled.'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.component_end;
end;
/
