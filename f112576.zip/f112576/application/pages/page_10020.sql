prompt --application/pages/page_10020
begin
--   Manifest
--     PAGE: 10020
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>13295460441845663907
,p_default_application_id=>112576
,p_default_id_offset=>0
,p_default_owner=>'WKSP_CKEENAN2'
);
wwv_flow_api.create_page(
 p_id=>10020
,p_user_interface_id=>wwv_flow_api.id(17843674423292242897)
,p_name=>'About'
,p_alias=>'HELP'
,p_step_title=>'About'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(17843677720556242903)
,p_required_patch=>wwv_flow_api.id(17843676655282242902)
,p_protection_level=>'C'
,p_help_text=>'All application help text can be accessed from this page. The links in the "Documentation" region give a much more in-depth explanation of the application''s features and functionality.'
,p_last_updated_by=>'CKEENAN1@UIOWA.EDU'
,p_last_upd_yyyymmddhh24miss=>'20220107192644'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17843691147897242919)
,p_plug_name=>'About Page'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h1:t-ContentBlock--lightBG'
,p_plug_template=>wwv_flow_api.id(17843550814583242848)
,p_plug_display_sequence=>20
,p_plug_source=>'A 2021 University of Iowa Database Management application created by Cade Keenan, Cade Hanrahan, Josh Orth, Isaac McSorley, and Tim Cook. This application uses 2015 data to provide insight into flying habits at Chicago O''Hare International Airport.'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.component_end;
end;
/
