prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>13295460441845663907
,p_default_application_id=>112576
,p_default_id_offset=>0
,p_default_owner=>'WKSP_CKEENAN2'
);
wwv_flow_api.create_page(
 p_id=>10
,p_user_interface_id=>wwv_flow_api.id(17843674423292242897)
,p_name=>'Q6'
,p_alias=>'Q6'
,p_step_title=>'Q6'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ISAAC-MCSORLEY@UIOWA.EDU'
,p_last_upd_yyyymmddhh24miss=>'20211207194156'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13995464238410546016)
,p_plug_name=>'Q6: When there is a delay, what is the average delay time for each airline?'
,p_region_template_options=>'#DEFAULT#:t-Region--accent8:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(17843577177964242858)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<b> Answer </b> </br>',
'As you can see in both in the query results and the bar chart below, Frontier Airlines has the longest average delay times by far. This could factor in to decision making when choosing which airline to fly from.'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17863002435073863234)
,p_plug_name=>'Delay by Airline'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--accent15:t-Region--noBorder:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(17843577177964242858)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT AIRLINE.AIRLINE, ROUND(AVG(TOTALDELAY)) AS AVERAGEDELAY  ',
'',
'FROM DELAYED JOIN FLIGHTS ON FLIGHTS.FLIGHT_ID = DELAYED.FLIGHT_ID JOIN  AIRLINE  ',
'',
'ON AIRLINE.AIRLINEID = FLIGHTS.AIRLINEID GROUP BY AIRLINE.AIRLINE ',
'',
'ORDER BY AVERAGEDELAY DESC '))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(17863002550276863235)
,p_region_id=>wwv_flow_api.id(17863002435073863234)
,p_chart_type=>'bar'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(17863002635809863236)
,p_chart_id=>wwv_flow_api.id(17863002550276863235)
,p_seq=>10
,p_name=>'New'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT AIRLINE.AIRLINE, ROUND(AVG(TOTALDELAY)) AS AVERAGEDELAY  ',
'',
'FROM DELAYED JOIN FLIGHTS ON FLIGHTS.FLIGHT_ID = DELAYED.FLIGHT_ID JOIN  AIRLINE  ',
'',
'ON AIRLINE.AIRLINEID = FLIGHTS.AIRLINEID GROUP BY AIRLINE.AIRLINE ',
'',
'ORDER BY AVERAGEDELAY DESC '))
,p_items_value_column_name=>'AVERAGEDELAY'
,p_items_label_column_name=>'AIRLINE'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(17863002713931863237)
,p_chart_id=>wwv_flow_api.id(17863002550276863235)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'Airline '
,p_title_font_style=>'oblique'
,p_title_font_color=>'#000000'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(17863002850376863238)
,p_chart_id=>wwv_flow_api.id(17863002550276863235)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>' Average Delay Time (min) '
,p_title_font_style=>'oblique'
,p_title_font_color=>'#000000'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17903080133057511225)
,p_plug_name=>'Frontier Airline Pic'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--hiddenOverflow'
,p_region_attributes=>'style="width:100%"'
,p_plug_template=>wwv_flow_api.id(17843577177964242858)
,p_plug_display_sequence=>50
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_region_image=>'#APP_FILES#frontier4.jpg'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(18815118158183050597)
,p_name=>'Average Delay (in minutes) Per Airline'
,p_template=>wwv_flow_api.id(17843577177964242858)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--accent15:t-Region--noBorder:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT AIRLINE.AIRLINE, ROUND(AVG(TOTALDELAY)) AS AVERAGEDELAY  ',
'',
'FROM DELAYED JOIN FLIGHTS ON FLIGHTS.FLIGHT_ID = DELAYED.FLIGHT_ID JOIN  AIRLINE  ',
'',
'ON AIRLINE.AIRLINEID = FLIGHTS.AIRLINEID GROUP BY AIRLINE.AIRLINE ',
'',
'ORDER BY AVERAGEDELAY DESC '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(17843614794487242872)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(18815118532369050598)
,p_query_column_id=>1
,p_column_alias=>'AIRLINE'
,p_column_display_sequence=>10
,p_column_heading=>'Airline'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(18815118974591050599)
,p_query_column_id=>2
,p_column_alias=>'AVERAGEDELAY'
,p_column_display_sequence=>20
,p_column_heading=>'Average Delay Time (minutes)'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.component_end;
end;
/
