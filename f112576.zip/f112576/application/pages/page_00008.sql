prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>13295460441845663907
,p_default_application_id=>112576
,p_default_id_offset=>0
,p_default_owner=>'WKSP_CKEENAN2'
);
wwv_flow_api.create_page(
 p_id=>8
,p_user_interface_id=>wwv_flow_api.id(17843674423292242897)
,p_name=>'Q2'
,p_alias=>'Q2'
,p_step_title=>'Q2'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'ISAAC-MCSORLEY@UIOWA.EDU'
,p_last_upd_yyyymmddhh24miss=>'20211210171042'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13995465483324546028)
,p_plug_name=>'Q2: Which airlines have the highest percentage chance of a flight getting canceled?'
,p_region_template_options=>'#DEFAULT#:t-Region--accent8:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(17843577177964242858)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<b>Answer</b> </br>',
'As you can see in the query results below, if a passenger chooses to fly through American Eagle Airlines (MQ) they statistically have the highest chance of their flight getting canceled based off of the flights we analyzed in 2015. Alaska Airlines ha'
||'d the lowest percentage of canceled flights. '))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(20452098365411404501)
,p_plug_name=>'Chance of Cancelation by Airline'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(17843577177964242858)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT AIRLINE.Airline, FLIGHTS.AIRLINEID, ROUND(COUNT(CANCELLED)/TotalFlights,3) AS Percentage_Cancelled FROM FLIGHTS JOIN (SELECT AIRLINEID, COUNT(AIRLINEID) AS TotalFlights FROM FLIGHTS GROUP BY AIRLINEID) T ON T.AirlineID = FLIGHTS.AirlineID  ',
'',
'JOIN AIRLINE ON AIRLINE.AIRLINEID = FLIGHTS.AIRLINEID ',
'',
'WHERE CANCELLED = ''1'' GROUP BY FLIGHTS.AIRLINEID, TotalFlights, AIRLINE.Airline ',
'',
'ORDER BY ROUND(COUNT(CANCELLED)/TotalFlights,3) DESC '))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(20452098447092404502)
,p_region_id=>wwv_flow_api.id(20452098365411404501)
,p_chart_type=>'bar'
,p_title=>'Chance of Cancelation by Airline'
,p_height=>'400'
,p_animation_on_display=>'alphaFade'
,p_animation_on_data_change=>'auto'
,p_orientation=>'horizontal'
,p_data_cursor=>'on'
,p_data_cursor_behavior=>'smooth'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(20452098563457404503)
,p_chart_id=>wwv_flow_api.id(20452098447092404502)
,p_seq=>10
,p_name=>'Cancelation by Airport'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT AIRLINE.Airline, FLIGHTS.AIRLINEID, ROUND(COUNT(CANCELLED)/TotalFlights,3) AS Percentage_Cancelled FROM FLIGHTS JOIN (SELECT AIRLINEID, COUNT(AIRLINEID) AS TotalFlights FROM FLIGHTS GROUP BY AIRLINEID) T ON T.AirlineID = FLIGHTS.AirlineID  ',
'',
'JOIN AIRLINE ON AIRLINE.AIRLINEID = FLIGHTS.AIRLINEID ',
'',
'WHERE CANCELLED = ''1'' GROUP BY FLIGHTS.AIRLINEID, TotalFlights, AIRLINE.Airline ',
'',
'ORDER BY ROUND(COUNT(CANCELLED)/TotalFlights,3) DESC '))
,p_items_value_column_name=>'PERCENTAGE_CANCELLED'
,p_items_label_column_name=>'AIRLINE'
,p_color=>'#34aadc'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(20452098665233404504)
,p_chart_id=>wwv_flow_api.id(20452098447092404502)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'Airline'
,p_title_font_family=>'Comic Sans MS'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(20452098766630404505)
,p_chart_id=>wwv_flow_api.id(20452098447092404502)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Chance of Cancelation (%)'
,p_title_font_family=>'Comic Sans MS'
,p_format_type=>'percent'
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_api.component_end;
end;
/
