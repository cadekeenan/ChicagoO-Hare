prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>13295460441845663907
,p_default_application_id=>112576
,p_default_id_offset=>0
,p_default_owner=>'WKSP_CKEENAN2'
);
wwv_flow_api.create_page(
 p_id=>4
,p_user_interface_id=>wwv_flow_api.id(17843674423292242897)
,p_name=>'Flights'
,p_alias=>'FLIGHTS'
,p_step_title=>'Flights'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'CKEENAN1@UIOWA.EDU'
,p_last_upd_yyyymmddhh24miss=>'20211206203610'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(18254753921368402679)
,p_plug_name=>'Flights'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(17843572897620242856)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select FLIGHT_ID,',
'       DATE_,',
'       DAY_OF_WEEK,',
'       AIRLINEID,',
'       FLIGHT_NUMBER,',
'       TAIL_NUMBER,',
'       DESTINATIONAIRPORTID,',
'       CANCELLED,',
'case ',
'WHEN CANCELLED = ''1'' THEN ''Yes''',
'WHEN CANCELLED = ''0'' THEN ''No'' END',
'from FLIGHTS;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Flights'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(18254754043160402680)
,p_name=>'Flights'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'CKEENAN1@UIOWA.EDU'
,p_internal_uid=>18254754043160402680
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18254754431489402681)
,p_db_column_name=>'FLIGHT_ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Flight ID'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18254754813144402682)
,p_db_column_name=>'DATE_'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Date '
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18254755289398402682)
,p_db_column_name=>'DAY_OF_WEEK'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Day Of Week'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18254755641270402682)
,p_db_column_name=>'AIRLINEID'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Airline ID'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18254756030544402682)
,p_db_column_name=>'FLIGHT_NUMBER'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Flight Number'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18254756477845402682)
,p_db_column_name=>'TAIL_NUMBER'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Tail Number'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18254756853566402683)
,p_db_column_name=>'DESTINATIONAIRPORTID'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Destination Airport ID'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18838160494619636607)
,p_db_column_name=>'CANCELLED'
,p_display_order=>17
,p_column_identifier=>'I'
,p_column_label=>'Cancelled'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(18838160567270636608)
,p_db_column_name=>'CASEWHENCANCELLED=''1''THEN''YES''WHENCANCELLED=''0''THEN''NO''END'
,p_display_order=>27
,p_column_identifier=>'J'
,p_column_label=>'Cancelled'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(18537942374533972445)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'185379424'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FLIGHT_ID:DATE_:DAY_OF_WEEK:AIRLINEID:FLIGHT_NUMBER:TAIL_NUMBER:DESTINATIONAIRPORTID:CASEWHENCANCELLED=''1''THEN''YES''WHENCANCELLED=''0''THEN''NO''END'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(18537631414610994302)
,p_plug_name=>'<b> Flights <b>'
,p_region_template_options=>'#DEFAULT#:t-Region--accent8:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(17843577177964242858)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(17842686087517242818)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(17843651399565242887)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_header=>'Each flight from the data set is unique and followed by the flight date (day, month, year), day of the week in which flight occurred, each flight''s airline ID, flight number, destination of flight, and whether it was cancelled or not.'
);
wwv_flow_api.component_end;
end;
/
