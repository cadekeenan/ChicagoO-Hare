prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>13295460441845663907
,p_default_application_id=>112576
,p_default_id_offset=>0
,p_default_owner=>'WKSP_CKEENAN2'
);
wwv_flow_api.create_page(
 p_id=>11
,p_user_interface_id=>wwv_flow_api.id(17843674423292242897)
,p_name=>'Q3'
,p_alias=>'Q3'
,p_step_title=>'Q3'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ISAAC-MCSORLEY@UIOWA.EDU'
,p_last_upd_yyyymmddhh24miss=>'20211207005741'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17863001377966863223)
,p_plug_name=>'Q3: What are the reasons for flight delays and how likely are they to occur?'
,p_region_template_options=>'#DEFAULT#:t-Region--accent8:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(17843577177964242858)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_menu_id=>wwv_flow_api.id(17842686087517242818)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(17843651399565242887)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13995465394788546027)
,p_plug_name=>'Answer'
,p_parent_plug_id=>wwv_flow_api.id(17863001377966863223)
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(17843577177964242858)
,p_plug_display_sequence=>10
,p_plug_source=>'As seen in the query results below, when there is a delay the biggest reason is from an <b>air system delay</b>, followed by an <b>airline delay</b> and <b>late aircraft delay</b>. Although <b>weather</b> is often thought of to be the biggest reason '
||'for delayed flights, we have found that is not true, weather is only the reason 27% of the time flights are delayed. If you are wondering what the chance is that any given flight will be delayed, that information is represented in Q5.'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(19700361919835999239)
,p_name=>'Q3'
,p_template=>wwv_flow_api.id(17843572897620242856)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ROUND(   ',
'',
'(SELECT COUNT(Flight_ID) FROM Delayed  ',
'',
'WHERE Air_System_Delay <> ''0'') /  ',
'',
'(SELECT COUNT(Flight_ID) FROM Delayed),4) * 100 || ''%'' AS Air_System_Delay,   ',
'',
'ROUND(   ',
'',
'(SELECT COUNT(Flight_ID) FROM Delayed  ',
'',
'WHERE Security_Delay <> ''0'') /  ',
'',
'(SELECT COUNT(Flight_ID) FROM Delayed),4) * 100 || ''%'' AS Security_Delay,  ',
'',
'ROUND(   ',
'',
'(SELECT COUNT(Flight_ID) FROM Delayed  ',
'',
'WHERE Airline_Delay <> ''0'') /  ',
'',
'(SELECT COUNT(Flight_ID) FROM Delayed),4) * 100 || ''%'' AS Airline_Delay,  ',
'',
'ROUND(   ',
'',
'(SELECT COUNT(Flight_ID) FROM Delayed  ',
'',
'WHERE Late_Aircraft_Delay <> ''0'') /  ',
'',
'(SELECT COUNT(Flight_ID) FROM Delayed),4) * 100 || ''%'' AS Late_Aircraft_Delay,  ',
'',
'ROUND(   ',
'',
'(SELECT COUNT(Flight_ID) FROM Delayed  ',
'',
'WHERE Weather_Delay <> ''0'') /  ',
'',
'(SELECT COUNT(Flight_ID) FROM Delayed),4) * 100 || ''%'' AS Weather_Delay  ',
'',
'FROM Delayed   ',
'',
'FETCH FIRST ROW ONLY '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(17843614794487242872)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(13995464808364546022)
,p_query_column_id=>1
,p_column_alias=>'AIR_SYSTEM_DELAY'
,p_column_display_sequence=>10
,p_column_heading=>'Air System Delay'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(13995464921872546023)
,p_query_column_id=>2
,p_column_alias=>'SECURITY_DELAY'
,p_column_display_sequence=>20
,p_column_heading=>'Security Delay'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(13995465044302546024)
,p_query_column_id=>3
,p_column_alias=>'AIRLINE_DELAY'
,p_column_display_sequence=>30
,p_column_heading=>'Airline Delay'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(13995465125672546025)
,p_query_column_id=>4
,p_column_alias=>'LATE_AIRCRAFT_DELAY'
,p_column_display_sequence=>40
,p_column_heading=>'Late Aircraft Delay'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(13995465235620546026)
,p_query_column_id=>5
,p_column_alias=>'WEATHER_DELAY'
,p_column_display_sequence=>50
,p_column_heading=>'Weather Delay'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.component_end;
end;
/
